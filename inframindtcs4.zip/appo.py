import flask
from flask import request
app=flask.Flask(__name__)
app.config["DEBUG"] = True
from flask_cors import CORS
CORS(app)
@app.route('/')
def home():
    return '<h1> API SERVER IS WORKING </h1>'
@app.route('/predict')
def predict():
    import joblib
    model=joblib.load('sentiment_analysis_model.ml')
    example = ["I am unhappy"]
    analysis_predict=model.predict(example)
    return str(analysis_predict)
app.run()
